# Tangent Parking Lot

**Last Updated:** February 10, 2026, 11:00 AM CST
**Next Review:** Monday, February 17, 2026, 10:00 AM CST (weekly)

---

## 🔥 IMPORTANT (Scheduled for Dedicated Sessions)

### Diagnosis & Operating Parameters Discussion

**Status:** SCHEDULED - Today (late afternoon/evening after LLM setup)
**Priority:** HIGH - Foundation for all future collaboration
**Topics to Cover:**

- C-PTSD patterns, triggers, and accommodations
- ADHD/OCD interaction patterns (how they compound/conflict)
- Hobbies and interests deep dive (for context building)
- Focus Shepherd parameter refinement based on patterns
- Communication adjustments based on neurological context

**Why Important:**

- Therapist-approved discussion (no shame)
- Stop "working blind" on cognitive patterns
- Establish baseline for effective collaboration
- Identify accommodation needs vs. preferences

**Estimated Time:** 2-3 hours dedicated session
**Best Timing:** Late today after LLM setup complete
**Scheduled:** February 10, 2026, late afternoon/evening

---

## 🎯 HIGH PRIORITY

### Local LLM Instance Setup (Ollama)

**Status:** IN PROGRESS - Today's primary task
**Context:** Want more AI access time per day, reduce dependence on free tier limits
**Need:** Set up local LLM with Ollama
**Topics:**

- Ollama installation and configuration
- Best model for our work (Llama, Mistral, etc.)
- Porting Focus Shepherd protocols to local instance
- Maintaining tangent system across instances
- Hardware requirements/recommendations
  **Hardware Inventory:** Doing quick inventory first (MacPro3,1 vs Ryzen, multiple HDs/CPUs)
  **Estimated Time:** 2-3 hours initial setup + testing
  **Scheduled:** February 10, 2026, 11:45 AM - 1:30 PM
  **Next Step:** Quick hardware inventory, then setup discussion

### Notion GTD Pages Setup

**Status:** SCHEDULED for tomorrow
**Context:** User has Notion, wants GTD (Getting Things Done) workflow
**Need:** Catalogue all ideas and projects to non-volatile medium
**Why Urgent:** User tends to overwrite/forget items for long stretches
**Blockers:** None
**Estimated Time:** 1-2 hours
**Scheduled:** February 11, 2026
**Next Step:** Dedicated session tomorrow to build GTD structure

---

## 📋 MEDIUM PRIORITY

### Focus Shepherd Skill - Public Availability

**Context:** We've built effective ADHD/tangent management protocols
**Need:** Determine if/how to make this publicly available
**Questions:**

- Would this help other ADHD users?
- What format? (Blog post, GitHub repo, Claude skill file?)
- Should we refine more first?
  **Estimated Time:** 1-2 hours to package for public release
  **Next Step:** Discuss value proposition and format options

### PC Parts & Materials Inventory (Full)

**Context:** Need to know what hardware is on hand
**Need:** Complete inventory of:

- PC parts (CPUs, GPUs, RAM, storage, etc.)
- Materials (wood, metals, old non-PC parts)
- Document condition and potential uses
  **Note:** Quick LLM-relevant inventory happening today first
  **Estimated Time:** 2-3 hours for thorough inventory
  **Next Step:** After LLM setup, schedule full inventory session

### Personal Website Refactoring

**Context:** 

- Current sites: tallest.ohmytallest.productions, omtp-software.ohmytallest.productions
- User is "tinkerer" - always optimizing
  **Need:** Architecture review, modernization recommendations
  **Blockers:** Need to see current structure
  **Estimated Time:** 2-4 hours depending on scope
  **Next Step:** User provides access/structure, we review

### Sanguihedral Payment Chain Setup

**Context:** VTM character management app concept
**Need:** Payment integration architecture (Kofi/Patreon/Throne/Braintree)
**Blockers:** App architecture decisions
**Dependencies:** May need Sanguihedral core design first
**Estimated Time:** 1-2 hours for architecture planning
**Next Step:** Determine if app design should precede this

### Software Stack Standardization Across Systems

**Status:** PROMOTED from Low Priority
**Context:** User has multiple systems, wants consistency
**Need:** Audit current stacks, recommend standardization
**Blockers:** Need inventory of systems
**Estimated Time:** 2-3 hours for audit + recommendations
**Next Step:** User provides system inventory

---

## 💡 LOW PRIORITY / WHEN INSPIRATION STRIKES

### Twitch/YouTube Streaming Comeback

**Context:** User has streaming history, considering return
**Need:** Strategy, technical setup, content planning
**Blockers:** None, just timing/motivation
**Estimated Time:** Variable - could be ongoing project
**Next Step:** When user decides to pursue

### Guitar/Bass Riff Recording + Vector AI

**Context:** Music recording/production interest
**Need:** Workflow for capturing riffs, potential AI integration
**Blockers:** None
**Estimated Time:** Exploratory session
**Next Step:** When musical inspiration hits

### Budgeting Post-Job

**Context:** Financial planning after employment change
**Need:** Budget framework and tracking
**Blockers:** None (but user has therapist for major decisions)
**Note:** Claude can provide frameworks, not financial advice
**Estimated Time:** 1-2 hours
**Next Step:** When user ready to tackle

---

## 📦 ACTIVE PROJECT NOTES

### Marcus Gruene (VTM V5)

**Status:** Corrections phase - nearly complete
**Remaining:**

- Apply corrections (Animal Form removal, XP log format, etc.)
- Update Google Sheet
- Submit to ST team
  **Blockers:** None
  **Next Session:** Today if context remains after Diagnosis discussion
  **Priority:** Get submitted this week

### Greater Arthia Campaign (Pathfinder 1E)

**Status:** Exploration phase
**Context:** Pathfinder 1st Edition campaign (D&D variant from OGL/SRD)
**Documents:** Campaign intro docs uploaded
**Next Step:** Clarify what kind of support needed (character creation, world building, etc.)
**Priority:** Low - on back burner while other items active

---

## 🗓️ WEEKLY REVIEW PROTOCOL

**Schedule:** Mondays, 10:00-11:00 AM CST (during work block)
**Next Review:** February 17, 2026, 10:00 AM

**Review Process:**

1. Go through each section
2. Update status on items
3. Reprioritize based on current state
4. Move completed items to archive
5. Add new tangents from week
6. Schedule any IMPORTANT tangents

**Estimated Time:** 15-30 minutes

---

## ✅ COMPLETED TANGENTS

### February 10, 2026

- [x] **Parking Lot Review** - Completed 11:00 AM
- [x] **D:\Docs\Claude folder structure setup** - Completed overnight

---

## 📊 STATISTICS (for pattern recognition)

**Total Active Tangents:** 14

- IMPORTANT: 1 (Diagnosis - scheduled today)
- High Priority: 2 (Local LLM, Notion GTD)
- Medium Priority: 5 (Focus Shepherd public, PC inventory, websites, Sanguihedral payments, software standardization)
- Low Priority: 3 (Streaming, music, budgeting)
- Active Projects: 2 (Marcus - urgent, Greater Arthia - back burner)

**Week Activity:**

- New tangents added: 5 (Local LLM, Focus Shepherd public, PC inventory, hardware choices, Notion urgency)
- Tangents promoted: 1 (Software standardization: Low → Medium)
- Tangents scheduled: 2 (Diagnosis today, Notion GTD tomorrow)
- Tangents completed: 2 (Parking lot review, folder setup)

**Pattern:** High technical/infrastructure focus this week (LLM setup, hardware inventory, GTD system)

---

## 📝 NOTES

**Today's Focus (Feb 10):**
Primary task is Local LLM setup to address token/context limits. This will enable more frequent/longer sessions without hitting free tier boundaries.

**Tomorrow's Focus (Feb 11):**
Notion GTD setup to capture all ideas/projects to prevent overwriting/forgetting (user-identified pain point).

**This Week Priority:**
Get Marcus Gruene submitted to ST team.

---

**NOTES FOR CLAUDE:**

- User is VERY decisive today - clear priorities, concrete scheduling
- Focus on LLM setup as primary deliverable
- Diagnosis discussion scheduled for late today (be ready for 2-3 hour deep dive)
- Watch for: Lunch break around 2 PM, energy levels after long sessions

**NOTES FOR USER:**

- You're being awesome at decision-making today!
- Schedule is packed but achievable
- Remember: You can always reschedule Diagnosis if LLM setup runs long
- This is YOUR parking lot - adjust anytime
